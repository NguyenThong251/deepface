# Utilities for common functions
