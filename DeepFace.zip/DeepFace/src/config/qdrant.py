db_qdrant = {
   "url":"http://localhost:6333/"
}